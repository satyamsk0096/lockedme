package com.lockedme;

public class LockedMeMain {
    public static void main(String[] args) {


        DirFileOperations.createMainFolderIfNotPresent("main");

        FileMenuOptions.printWelcomeScreen("LockedMe", "Satyam Singh");

        HandleOptions.handleWelcomeScreenInput();

    }

}
